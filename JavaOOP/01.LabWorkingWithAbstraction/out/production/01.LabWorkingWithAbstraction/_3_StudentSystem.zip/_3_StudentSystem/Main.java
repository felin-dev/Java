package _3_StudentSystem;

public class Main {
    public static void main(String[] args) {
        StudentCommandsReceiver.getTheStudentsCommands();
    }
}
