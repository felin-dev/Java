package _5_JediGalaxyBuffered;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Arrays;

public class ProcessGalaxyFromScanner {
    private static long totalStarsCollected;
    private final int[][] galaxy;


    public ProcessGalaxyFromScanner(int[][] galaxy) {
        this.galaxy = galaxy;
    }

    public void processCommands() throws IOException {
        BufferedReader reader = Main.reader;
        String command = reader.readLine();
        totalStarsCollected = 0;
        readCommands(reader, galaxy, command);
    }

    private static void readCommands(BufferedReader reader, int[][] galaxy, String command) throws IOException {
        while (!command.equals("Let the Force be with you")) {
            int[] jediIvoCoordinates = Arrays.stream(command.split(" ")).mapToInt(Integer::parseInt).toArray();
            int[] evilCoordinates = Arrays.stream(reader.readLine().split(" ")).mapToInt(Integer::parseInt).toArray();
            int evilRow = evilCoordinates[0];
            int evilCol = evilCoordinates[1];

            while (evilRow >= 0 && evilCol >= 0) {
                if (evilRow < galaxy.length && evilCol < galaxy[0].length) {
                    galaxy[evilRow][evilCol] = 0;
                }
                evilRow--;
                evilCol--;
            }

            int jediRow = jediIvoCoordinates[0];
            int jediCol = jediIvoCoordinates[1];

            while (jediRow >= 0 && jediCol < galaxy[1].length) {
                if (jediRow < galaxy.length && jediCol >= 0 && jediCol < galaxy[0].length) {
                    totalStarsCollected += galaxy[jediRow][jediCol];
                }

                jediCol++;
                jediRow--;
            }

            command = reader.readLine();
        }
    }

    public static void printTotalStarsCollected() {
        System.out.println(totalStarsCollected);
    }

    @Override
    public String toString() {
        return String.format("%o", totalStarsCollected);
    }
}
