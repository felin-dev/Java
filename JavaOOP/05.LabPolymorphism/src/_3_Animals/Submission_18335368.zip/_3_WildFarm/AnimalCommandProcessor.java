package _3_WildFarm;

import _3_WildFarm.Food.Food;
import _3_WildFarm.Food.Meat;
import _3_WildFarm.Food.Vegetable;
import _3_WildFarm.Utilities.InputParser;

public class AnimalCommandProcessor {

    private final InputParser reader;
    private final AnimalsList animalsList;

    public AnimalCommandProcessor(InputParser reader, AnimalsList animalsList) {
        this.reader = reader;
        this.animalsList = animalsList;
    }

    public void processCommands() {
        String command;
        while (!(command = reader.parseCommand()).equals("End")) {
            String[] animalInfo = command.split("\\s+");
            String animalType = animalInfo[0];
            String[] foodInfo = reader.parseSplitCommand("\\s+");
            animalsList.put(animalType, animalInfo);
            animalsList.get(animalType).makeSound();

            try {
                animalsList.get(animalType).eat(getFood(foodInfo));
            } catch (IllegalStateException exception) {
                System.out.println(exception.getMessage());
            }
        }
    }

    private Food getFood(String[] foodInfo) {
        return foodInfo[0].equals("Vegetable") ?
                new Vegetable(Integer.parseInt(foodInfo[1])) :
                new Meat(Integer.parseInt(foodInfo[1]));
    }
}
