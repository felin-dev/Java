package _3_WildFarm.Animals;

public abstract class Mammal extends Animal {

    protected Mammal(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
