package _3_WildFarm;

import _3_WildFarm.Animals.*;
import _3_WildFarm.Food.Food;
import _3_WildFarm.Food.Meat;
import _3_WildFarm.Food.Vegetable;
import _3_WildFarm.Utilities.InputParser;

import java.util.LinkedHashMap;
import java.util.Map;

public class AnimalCommandProcessor {

    private final InputParser reader;

    public AnimalCommandProcessor(InputParser reader) {
        this.reader = reader;
    }

    public void processCommands() {
        Map<String, Animal> animals = new LinkedHashMap<>();
        String command;
        while (!(command = reader.parseCommand()).equals("End")) {
            String[] animalInfo = command.split("\\s+");
            String animalType = animalInfo[0];
            animals.put(animalType, createNewAnimal(animalInfo));
            animals.get(animalType).makeSound();

            String[] foodInfo = reader.parseSplitCommand("\\s+");
            try {
                animals.get(animalType).eat(getFood(foodInfo));
            } catch (IllegalStateException exception) {
                System.out.println(exception.getMessage());
            }
        }

        for (Animal animal : animals.values()) {
            System.out.println(animal.toString());
        }
    }

    private Food getFood(String[] foodInfo) {
        return foodInfo[0].equals("Vegetable") ?
                new Vegetable(Integer.parseInt(foodInfo[1])) :
                new Meat(Integer.parseInt(foodInfo[1]));
    }

    private Animal createNewAnimal(String[] tokens) {
        switch (tokens[0]) {
            case "Mouse":
                return new Mouse(tokens[0], tokens[1], Double.parseDouble(tokens[2]), tokens[3]);
            case "Zebra":
                return new Zebra(tokens[0], tokens[1], Double.parseDouble(tokens[2]), tokens[3]);
            case "Cat":
                return new Cat(tokens[0], tokens[1], Double.parseDouble(tokens[2]), tokens[3], tokens[4]);
            case "Tiger":
                return new Tiger(tokens[0], tokens[1], Double.parseDouble(tokens[2]), tokens[3]);
            default:
                throw new IllegalArgumentException("There is no such animal in the known animal list.");
        }
    }
}
