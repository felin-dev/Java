package _3_Scale;

public class Main {
    public static void main(String[] args) {
    }
}