package vetClinic;

import java.util.ArrayList;
import java.util.List;

public class Clinic {
    private List<Pet> data;
    private int capacity;

    public Clinic(int capacity) {
        this.data = new ArrayList<>();
        this.capacity = capacity;
    }

    //check the capacity
    public void add(Pet pet) {
        if (this.capacity >= this.data.size()) {
            this.data.add(pet);
        }
    }

    public boolean remove(String name) {
        return this.data.removeIf(pet -> pet.getName().equals(name));
    }

    public Pet getPet(String name, String owner) {
        Pet wantedPet = null;
        for (Pet pet : this.data) {
            if (pet.getName().equals(name) && pet.getOwner().equals(owner)) {
                wantedPet = pet;
            }
        }

        return wantedPet;
    }

    public Pet getOldestPet() {
        Pet oldestPet = null;
        int maxAge = Integer.MIN_VALUE;
        for (Pet pet : this.data) {
            if (pet.getAge() > maxAge) {
                oldestPet = pet;
                maxAge = pet.getAge();
            }
        }

        return oldestPet;
    }

    public int getCount() {
        return this.data.size();
    }

    public String getStatistics() {
        StringBuilder output = new StringBuilder();
        output.append(String.format("The clinic has the following patients:%n"));
        for (Pet pet : data) {
            output.append(String.format("%s %s%n", pet.getName(), pet.getOwner()));
        }
        return output.toString().trim();
    }
    //Next, write a Java class Clinic that has data (a collection, which stores the Pets).
    // All entities inside the repository have the same fields. Also, the Clinic class should have those filelds:
    //•	capacity: int
    //The class constructor should receive capacity, also it should initialize the data with a
    // new instance of the collection. Implement the following features:
    //•	Field data – List that holds added pets
    //•	Method add(Pet pet) – adds an entity to the data if there is an empty cell for the pet.
    //•	Method remove(String name) – removes the pet by given name, if such exists, and returns boolean.
    //•	Method getPet(String name, String owner) – returns the pet with the given name
    // and owner or null if no such pet exists.
    //•	Method getOldestPet() – returns the oldest Pet.
    //•	Getter getCount – returns the number of pets.
    //•	getStatistics() – returns a String in the following format:
    //o	"The clinic has the following patients:
    //{name} {owner}
    //{name} {owner}
    //   (…)"
}
