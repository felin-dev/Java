package _4_RawData;

import java.util.Map;

public class Tyres {
    private final Map<Double, Integer> tyreInfo;

    Tyres(Map<Double, Integer> tyreInfo) {
        this.tyreInfo = tyreInfo;
    }

    public Map<Double, Integer> getTyreInfo() {
        return this.tyreInfo;
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();
        this.tyreInfo.forEach((pressure, age) -> output.append(String.format("%.2f, %d%n", pressure, age)));

        return output.toString();
    }
}