package _9_CatLady;

public interface Cat {
        String ToString();
}
