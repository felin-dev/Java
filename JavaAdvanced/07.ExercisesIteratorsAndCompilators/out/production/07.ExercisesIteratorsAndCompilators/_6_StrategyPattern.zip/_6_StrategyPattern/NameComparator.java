package _6_StrategyPattern;

import java.util.Comparator;

public class NameComparator implements Comparator<Person> {
    @Override
    public int compare(Person firstPerson, Person secondPerson) {
        int result = Integer.compare(firstPerson.getName().length(), secondPerson.getName().length());
        if (result == 0) {
            result = Character.compare(firstPerson.getName().charAt(0), secondPerson.getName().charAt(0));
        }

        return result;
    }

    //The first comparator should compare people based on the length of their name
    // as a first parameter, if 2 people have a name with the same length, perform
    // a case-insensitive compare based on the first letter of their name instead.
    // The second comparator should compare them based on their age. Create 2 TreeSets
    // of type Person, the first should implement the name comparator and the second
    // should implement the age comparator.
}
