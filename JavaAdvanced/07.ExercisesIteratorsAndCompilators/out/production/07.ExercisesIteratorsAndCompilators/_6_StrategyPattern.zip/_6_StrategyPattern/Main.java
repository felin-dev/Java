package _6_StrategyPattern;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<Person> people = new ArrayList<>();
        IntStream.range(0, Integer.parseInt(sc.nextLine()))
                .forEach(i -> {
                    String[] personInfo = sc.nextLine().split("\\s+");
                    String name = personInfo[0];
                    int age = Integer.parseInt(personInfo[1]);
                    Person person = new Person(name, age);
                    people.add(person);
                });

        StringBuilder output = new StringBuilder();
        people.sort(new NameComparator());
        for (Person person : people) {
            output.append(person).append(System.lineSeparator());
        }

        people.sort(new AgeComparator());
        for (Person person : people) {
            output.append(person).append(System.lineSeparator());
        }

        System.out.println(output);
    }
}
